INSERT INTO Flight (DepartureAirport, TargetAirport, DepartureTime, ArrivalTime, Date)
VALUES ('BER', 'MAD', '09:32', '11:30', '2019-03-24');
